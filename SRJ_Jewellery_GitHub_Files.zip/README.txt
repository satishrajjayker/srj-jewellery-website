SRJ Jewellery Website
======================
Open index.html in any modern browser.

This is an original SRJ Jewellery concept with a premium Indian jewellery aesthetic inspired by the general conventions of luxury jewellery storefronts (not a copy of Tanishq branding or site code).

Images are loaded from Unsplash at runtime, so an internet connection is recommended.
